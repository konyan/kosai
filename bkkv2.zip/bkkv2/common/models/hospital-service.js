'use strict';

module.exports = function(Hospitalservice) {

};
