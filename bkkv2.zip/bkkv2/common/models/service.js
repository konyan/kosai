'use strict';

module.exports = function(Service) {

};
