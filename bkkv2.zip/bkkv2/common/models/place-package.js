'use strict';

module.exports = function(Placepackage) {

};
