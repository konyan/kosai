'use strict';

module.exports = function(Calculatorbooking) {

};
