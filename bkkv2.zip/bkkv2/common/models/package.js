'use strict';

module.exports = function(Package) {

};
