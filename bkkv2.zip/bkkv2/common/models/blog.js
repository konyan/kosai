'use strict';

module.exports = function(Blog) {

};
