'use strict';

module.exports = function(Blogcategory) {

};
