'use strict';

module.exports = function(Booking) {

};
