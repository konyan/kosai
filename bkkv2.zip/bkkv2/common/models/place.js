'use strict';

module.exports = function(Place) {

};
