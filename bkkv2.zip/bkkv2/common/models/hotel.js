'use strict';

module.exports = function(Hotel) {

};
