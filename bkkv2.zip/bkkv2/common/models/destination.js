'use strict';

module.exports = function(Destination) {

};
