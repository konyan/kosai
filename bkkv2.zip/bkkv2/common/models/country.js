'use strict';

module.exports = function(Country) {

};
