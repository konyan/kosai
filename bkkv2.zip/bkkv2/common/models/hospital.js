'use strict';

module.exports = function(Hospital) {

};
