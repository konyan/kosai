'use strict';

module.exports = function(Category) {

};
