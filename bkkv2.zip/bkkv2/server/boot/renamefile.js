module.exports = function(app) {
  app.dataSources.amazon.connector.getFilename = function(
    origFilename,
    req,
    res
  ) {
    var origFilename = origFilename.name;
    var parts = origFilename.split('.'),
      extension = parts[parts.length - 1];
    var newFilename = new Date().getTime() + '.' + extension;
    return newFilename;
  };
};
