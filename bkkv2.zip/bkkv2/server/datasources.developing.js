require('dotenv').config();

module.exports = {
  mongodb: {
    connector: 'mongodb',
    hostname: 'ds111804.mlab.com',
    port: '11804',
    user: 'root',
    password: 'admin',
    database: 'bangkokguide',
    url: 'mongodb://root:admin@ds111804.mlab.com:11804/bangkokguide'
  },
  amazon: {
    connector: "loopback-component-storage",
    provider: "amazon",
    key: process.env.AWS_KEY,
    keyId: process.env.AWS_KEYID,
    maxFileSize: "6297348"
  }
};
