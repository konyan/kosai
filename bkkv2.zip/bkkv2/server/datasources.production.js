require('dotenv').config();

module.exports = {
  mongodb: {
    connector: 'mongodb',
    hostname: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_DATABASE,
    url: process.env.DB_URL
  },
  amazon: {
    connector: "loopback-component-storage",
    provider: "amazon",
    key: process.env.AWS_KEY,
    keyId: process.env.AWS_KEYID,
    maxFileSize: "6297348"
  }
};
